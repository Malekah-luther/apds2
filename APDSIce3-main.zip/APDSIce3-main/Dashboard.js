// src/components/Dashboard.js
import React from 'react';

const Dashboard = () => {
  return (
    <div>
      <h2>Dashboard</h2>
      <p>Welcome to your dashboard! You are now logged in.</p>
    </div>
  );
};

export default Dashboard;
